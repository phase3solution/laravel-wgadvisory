<footer class="footer">
    <div class="container-fluid">
      <nav class="float-left">
        <ul>
          <li>
            <a href="{{url('/')}}">
                {{ __('Home') }}
            </a>
          </li>
          <li>
            <a href="https://wgadvisory.ca/" target="_blank">
                {{ __('About Us') }}
            </a>
          </li>
  
          <li>
            <a href="https://wgadvisory.ca/our-advisors.html" target="_blank">
                {{ __('Our Advisors') }}
            </a>
          </li>
        </ul>
      </nav>
      <div class="copyright float-right">
        All right reserved by
        <a href="https://www.wgadvisory.co" target="_blank">WG Advisory.</a>
        &copy;
        <script>
          document.write(new Date().getFullYear())
        </script>
      </div>
    </div>
  </footer>