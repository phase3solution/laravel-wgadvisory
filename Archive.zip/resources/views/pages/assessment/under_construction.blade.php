<div class="card-header card-header-primary">
    <h4 class="card-title"> Title </h4>
    <p class="card-category assessment-label ">Subtitle</p>
</div>


    <div class="card-body">
        <div class="row collapseBody0">
            <div class="col-md-12 rowBody0">
                
                <h5>404 !</h5>
                <h1>NOT FOUND</h1>
                <p>Under Construction</p>
                
            
            </div>
 
        </div>
    </div>



